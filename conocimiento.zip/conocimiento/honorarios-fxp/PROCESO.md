# Proceso: Honorarios médicos (FXP)

**Estado:** parcial  
**Módulo:** FXP_COL

No es FCXP. `ESTADO_FXP` consulta si el ítem ya está confirmado en MCP. `CAMBIAR_TERFXP` mueve el ítem de honorario; si la factura ya estaba contabilizada, `SPK_CONTAB_FTR` reconstruye el comprobante.
