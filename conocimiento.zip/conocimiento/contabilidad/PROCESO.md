# Proceso: Contabilidad

**Estado:** esqueleto  
**Módulo:** MCP_COL  
**Ventanas:** `/cont/mcp`, `/cont/mcpe`

> MCUE no está en INDICE_TABLAS. No inventar. Los SP se bajan a `sql/` el día que se analicen.

## Capas

1. Configuración
2. Proceso propio
3. Lo que llega y completa
4. Subproceso unido
5. Envío a contabilidad

## Cómo se va completando

La contabilización se documenta en la capa 3 de `proceso.json`: un control por procedencia. Cada hallazgo (error, documento, corrección, caso) se anota ahí. El cuerpo del procedimiento sigue en el proceso hermano (inventario, CxP, caja, facturación, etc.).

Lo que aún dice «solo el enlace» es un nombre que Reconstruir ya llama y cuyo cuerpo no está leído: nómina, anticipos, cesiones, legalización, glosa (`SPK_CONTAB_FGLO`), depreciación (`SPK_APL_AJDEPRECIACION`), activo (`SPK_CONTAB_IACT`) y radicación con abonos (`SPK_CONTAB_RADICACXC_1`).

## Del comprobante errado al origen

Pantalla: Contabilidad → Comprobantes errados (`/cont/mcpe`). El detalle vive en el control `mcpe-flujo-invertido` de `proceso.json`.

El texto de la línea lo escribe `SPK_REVISAR_COMPROBANTE`: cuenta inexistente, cuenta que no es de detalle, valor cero, valor negativo o tercero inexistente. La cabecera dice de qué módulo vino (`PROCEDENCIA`) y qué documento hay que abrir (`REFERENCIA1`, `REFERENCIA2`, `NOREFERENCIA`, sede).

Reconstruir vuelve a ejecutar el procedimiento de esa procedencia. La corrección va en el documento origen; después Revisar y Reconstruir.

En CEM, las familias ya dictaminadas son la dispensación tipo 06 sin centro de costo, el duplicado de referencia entre sedes al reconstruir, y el tercero que no es afiliado y tumba la categoría. El impuesto al consumo de CxP puede quedar en el libro y no en errados.
